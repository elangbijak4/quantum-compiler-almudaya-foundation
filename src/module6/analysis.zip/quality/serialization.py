"""
Module 6 Stage 9 — Quality Serialization (Initialization Scaffold).

Canonical JSON serialization and deserialization for QualityProfile and ComparisonResult.
"""

import json
from src.module6.quality.model import (
    ResourceProfile,
    QualityProfile,
    ComparisonResult,
    ResultClassification,
    ParetoStatus,
)


def serialize_quality_profile(profile: QualityProfile) -> str:
    """Serializes QualityProfile into canonical JSON string."""
    return json.dumps(profile.to_dict(), indent=2, sort_keys=True)


def deserialize_quality_profile(json_str: str) -> QualityProfile:
    """Deserializes canonical JSON string into QualityProfile."""
    data = json.loads(json_str)
    r_data = data["resource_profile"]
    res_prof = ResourceProfile(
        total_qubits=r_data["total_qubits"],
        data_qubits=r_data["data_qubits"],
        ancilla_qubits=r_data["ancilla_qubits"],
        total_gate_count=r_data["total_gate_count"],
        circuit_depth=r_data["circuit_depth"],
        t_gate_count=r_data["t_gate_count"],
        t_gate_depth=r_data["t_gate_depth"],
        cnot_gate_count=r_data["cnot_gate_count"],
        cnot_depth=r_data["cnot_depth"],
        gate_distribution=r_data["gate_distribution"],
    )

    return QualityProfile(
        semantic_equivalence_verified=data["semantic_equivalence_verified"],
        feasibility_status=data["feasibility_status"],
        resource_profile=res_prof,
        optimization_reduction=data["optimization_reduction"],
        vocabulary_compatibility=data["vocabulary_compatibility"],
        provenance_completeness=data["provenance_completeness"],
        classification=ResultClassification(data["classification"]),
        weighted_quality_score=data.get("weighted_quality_score"),
    )
