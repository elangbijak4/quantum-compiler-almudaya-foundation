"""
Module 6 Stage 9 — Resource & Quality Evaluator (Initialization Scaffold).

Extracts ResourceProfile and constructs QualityProfile without hardware execution or noise simulation.
"""

from typing import Dict, Any, Optional
from src.module4.circuit_ir.model import QuantumCircuitIR
from src.module6.optimization.model import OptimizationCostReport
from src.module6.quality.model import (
    ResourceProfile,
    QualityProfile,
    ResultClassification,
)


class ResourceQualityEvaluator:
    """
    Evaluates exact resource profiles and constructs multi-objective quality profiles.
    
    Non-implication rules enforced:
    - QUALITY != SEMANTIC EQUIVALENCE
    - LOWER GATE COUNT != UNIVERSALLY BETTER CIRCUIT
    - LOWER DEPTH != UNIVERSALLY BETTER CIRCUIT
    - FEASIBLE != OPTIMAL
    """

    @classmethod
    def extract_resource_profile(cls, circuit: QuantumCircuitIR) -> ResourceProfile:
        """Extracts ResourceProfile from QuantumCircuitIR."""
        gate_counts: Dict[str, int] = {}
        t_count = 0
        cnot_count = 0

        for gate in circuit.gates:
            g_name = gate.gate_type.name if hasattr(gate.gate_type, 'name') else str(gate.gate_type)
            gate_counts[g_name] = gate_counts.get(g_name, 0) + 1
            if g_name == "T_GATE":
                t_count += 1
            elif g_name == "CNOT":
                cnot_count += 1

        ancilla_count = len(circuit.ancilla_declarations)
        total_q = circuit.total_width
        data_q = max(0, total_q - ancilla_count)

        return ResourceProfile(
            total_qubits=total_q,
            data_qubits=data_q,
            ancilla_qubits=ancilla_count,
            total_gate_count=len(circuit.gates),
            circuit_depth=len(circuit.gates),
            t_gate_count=t_count,
            t_gate_depth=t_count,
            cnot_gate_count=cnot_count,
            cnot_depth=cnot_count,
            gate_distribution=gate_counts,
        )

    @classmethod
    def evaluate_quality_profile(
        cls,
        circuit: QuantumCircuitIR,
        optimization_report: Optional[OptimizationCostReport] = None,
        semantic_equivalent: bool = True,
        feasibility_status: str = "FEASIBLE",
    ) -> QualityProfile:
        """Constructs QualityProfile from ResourceProfile and Stage 8 reports."""
        res_profile = cls.extract_resource_profile(circuit)

        opt_reduction = optimization_report.gate_count_reduction if optimization_report else 0
        vocab_compat = optimization_report.vocabulary_containment_verified if optimization_report else True

        classification = ResultClassification.SEMANTICALLY_VALID if semantic_equivalent else ResultClassification.INVALID

        return QualityProfile(
            semantic_equivalence_verified=semantic_equivalent,
            feasibility_status=feasibility_status,
            resource_profile=res_profile,
            optimization_reduction=opt_reduction,
            vocabulary_compatibility=vocab_compat,
            provenance_completeness=True,
            classification=classification,
            weighted_quality_score=None,
        )
